from Motif import *
import numpy as N

def computeSimMatrix(motifs,cores,distance=Motif.fisim,verbose=False):
	"""Crea una matriz de similitudes(distancias) comparando uno a uno los motivos de la lista motifs por medio de la medidad de similitud(distancia) especificada en distance.
	Si se cores != [] se calculan las distancias de los cores de los motivos a los motivos en si"""
	mat = N.zeros((len(motifs),len(motifs)),dtype=float)
	if verbose: print "Computando la similitud entre " + str(len(motifs)) + " motivos"
	for i in range(len(motifs)):
		if verbose: print "Procesando motivo " + str(i+1)
		for j in range(len(motifs)):
			if len(cores) == 0: mat[i,j] = distance(motifs[i],motifs[j])[0]
			else: mat[i,j] = (distance(cores[i],motifs[j])[0] + distance(motifs[i],cores[j])[0]) / 2 # Hago la media de las dos distancias para obtener una matriz simetrica

	return mat

def matrix2File(matrix,motifs,fileOut,ID=False):
	"""Escribe en el fichero fileOut la matriz de similitudes(distancias) para los motivos de la lista motifs (utilizada para saber los nombres de los motivos)
	ID es para indicar si se quieren usar los IDs de los motivos como nombres en lugar de los nombres propiamente dichos"""
	f = open(fileOut,'w')
	name = ''
	for i in range(len(motifs)):
		if ID: f.write('\t' + motifs[i].ID) # primera fila con los IDs
		else: f.write('\t' + motifs[i].name) # primera fila con los nombres
	for i in range(len(motifs)):
		if ID: f.write('\n'+motifs[i].ID) # primera columna con los IDs
		else: f.write('\n'+motifs[i].name) # primera columna con los nombres
		for j in range(len(motifs)):
			f.write('\t' + str(matrix[i,j]))
	f.write('\n') # El \n final

def createSimMatrix(motifs,cores,fileOut,distance=Motif.fisim,ID=False,verbose=False):
	"""Crea y escribe en el fichero fileOut una matriz de similitudes(distancias) comparando uno a uno los motivos de la lista motifs por medio de la medidad de similitud(distancia) especificada en distance"""
	mat = computeSimMatrix(motifs,cores,distance=distance,verbose=verbose)
	matrix2File(mat,motifs,fileOut,ID=ID)
